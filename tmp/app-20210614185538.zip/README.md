
## instalar zat
https://developer.zendesk.com/apps/docs/core-api/client_api#client.requestoptions

Luego isntalar 

ruby-dev
gcc
make
g++
zlibc
zlib1g
zlib1g-dev

# App name

[brief description of the app]

### The following information is displayed:

* info1
* info2
* info3

Please submit bug reports to [Insert Link](). Pull requests are welcome.

### Screenshot(s):
[put your screenshots down here.]

## Para mas informacion sobre el manifest visite:
https://developer.zendesk.com/apps/docs/developer-guide/manifest

## Para leer sobre los setins para usuarios cuando esta intalada la app:
https://developer.zendesk.com/apps/docs/developer-guide/setup#creating-a-settings-page-for-users


## para editar el servidor de sinatra en ruby:
C:\Users\javie\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu20.04onWindows_79rhkp1fndgsc\LocalState\rootfs\var\lib\gems\2.7.0\gems\zendesk_apps_tools-3.8.1\lib\zendesk_apps_tools

## OAuth
https://support.zendesk.com/hc/en-us/articles/203663836-Using-OAuth-authentication-with-your-application


## app submition
https://developer.zendesk.com/account/app_submissions


## Realización de solicitudes a la API de Zendesk
https://develop.zendesk.com/hc/en-us/articles/360001074168




